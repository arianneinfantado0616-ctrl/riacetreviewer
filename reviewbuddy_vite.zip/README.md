# ReviewBuddy

This is a Vite + React + Tailwind project containing the ReviewBuddy app.

How to run locally:
1. Install Node.js (v18+ recommended).
2. Run `npm install`.
3. Run `npm run dev` to start the dev server.
4. Build with `npm run build`. Preview the build with `npm run preview`.

This bundle was created by ChatGPT and includes the app source in `src/App.jsx`.
